package com.movieproject.theatreservice;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TheatreRepository extends CrudRepository<Theatre, Integer>{
	public List<Theatre> findByTheatrename(String theatrename);
}
