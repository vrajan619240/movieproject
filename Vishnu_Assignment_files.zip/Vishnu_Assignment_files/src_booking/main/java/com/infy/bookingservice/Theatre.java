package com.infy.bookingservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sun.istack.NotNull;

@Entity
@Table(name="theatre_table")
public class Theatre {
	
	@Id
	@Column(name="theatre_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer theatreId;
	
	@NotNull
	@Column(name="theatrename")
	private String theatrename;
	
	@NotNull
	private String address;
	
	@NotNull
	private Integer capacity;
	
	@NotNull
	private String place;

	public Theatre(Integer theatreId, String theatrename, String address, Integer capacity, String place) {
		super();
		this.theatreId = theatreId;
		this.theatrename = theatrename;
		this.address = address;
		this.capacity = capacity;
		this.place = place;
	}

	public Theatre() {
		
	}

	public Integer getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(Integer theatreId) {
		this.theatreId = theatreId;
	}

	public String getTheatrename() {
		return theatrename;
	}

	public void setTheatrename(String theatrename) {
		this.theatrename = theatrename;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

}
