package com.infy.bookingservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "movie_table")
public class Movie {
	
	@Id
	@Column(name = "movie_id")        	    
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer movieId;

	@NotNull
	@Column(name = "moviename") 
	private String movieName;

	@NotNull
	private String genre;

	private String rating;

	@NotNull
	private String language;

	public Movie(Integer movieId, String movieName, String genre, String rating, String language) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.genre = genre;
		this.rating = rating;
		this.language = language;
	}

	public Movie() {
		super();
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

}
